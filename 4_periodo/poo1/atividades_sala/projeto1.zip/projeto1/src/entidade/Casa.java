package entidade;

public class Casa {
  public Pessoa proprietario; 
 void mostraProprietario(){
	 System.out.println(this.proprietario.getNome());
 }
}


